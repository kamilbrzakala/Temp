import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Play, CheckCircle2, Clock, AlertCircle } from "lucide-react";
import { toast } from "sonner";

export type ReportStatus = "pending" | "running" | "completed" | "error";

export interface Report {
  id: string;
  title: string;
  description: string;
  progress: number;
  status: ReportStatus;
}

interface ReportCardProps {
  report: Report;
  onRun: (id: string) => void;
}

const statusConfig = {
  pending: {
    icon: Clock,
    color: "text-muted-foreground",
    label: "Pending",
  },
  running: {
    icon: Play,
    color: "text-primary glow-text",
    label: "Running",
  },
  completed: {
    icon: CheckCircle2,
    color: "text-primary",
    label: "Completed",
  },
  error: {
    icon: AlertCircle,
    color: "text-destructive",
    label: "Error",
  },
};

export function ReportCard({ report, onRun }: ReportCardProps) {
  const [isHovered, setIsHovered] = useState(false);
  const StatusIcon = statusConfig[report.status].icon;

  const handleRun = () => {
    if (report.status === "running") {
      toast.info("Report is already running");
      return;
    }
    onRun(report.id);
  };

  return (
    <Card
      className="group relative overflow-hidden border-border bg-card transition-all duration-300 hover:glow-border"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Gradient overlay on hover */}
      <div
        className={`absolute inset-0 bg-gradient-to-r from-transparent via-primary/10 to-transparent transition-opacity duration-300 ${
          isHovered ? "opacity-100" : "opacity-0"
        }`}
      />

      <div className="relative p-6 space-y-4">
        {/* Header */}
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-1">
            <h3 className="text-lg font-semibold text-foreground group-hover:text-primary transition-colors">
              {report.title}
            </h3>
            <p className="text-sm text-muted-foreground">{report.description}</p>
          </div>

          <Button
            variant="default"
            size="sm"
            onClick={handleRun}
            disabled={report.status === "running"}
            className="bg-primary/10 text-primary hover:bg-primary hover:text-primary-foreground border border-primary/30 hover:shadow-[0_0_15px_rgba(0,255,136,0.5)] transition-all duration-300"
          >
            <Play className="h-4 w-4 mr-1" />
            Run
          </Button>
        </div>

        {/* Status */}
        <div className="flex items-center gap-2">
          <StatusIcon className={`h-4 w-4 ${statusConfig[report.status].color}`} />
          <span className={`text-sm font-medium ${statusConfig[report.status].color}`}>
            {statusConfig[report.status].label}
          </span>
        </div>

        {/* Progress Bar */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-muted-foreground">
            <span>Progress</span>
            <span className="font-mono">{report.progress}%</span>
          </div>
          <Progress
            value={report.progress}
            className="h-2 bg-secondary"
            indicatorClassName={`${
              report.status === "running" ? "progress-glow" : ""
            } transition-all duration-500`}
          />
        </div>
      </div>

      {/* Bottom glow effect */}
      {report.status === "running" && (
        <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary to-transparent animate-pulse" />
      )}
    </Card>
  );
}
