import { useState, useEffect } from "react";
import { ReportCard, Report, ReportStatus } from "@/components/ReportCard";
import { toast } from "sonner";

const initialReports: Report[] = [
  {
    id: "1",
    title: "Market Analysis Report",
    description: "Comprehensive analysis of current market trends and indicators",
    progress: 0,
    status: "pending",
  },
  {
    id: "2",
    title: "Trading Volume Report",
    description: "Daily trading volume metrics across all exchanges",
    progress: 65,
    status: "running",
  },
  {
    id: "3",
    title: "Portfolio Performance",
    description: "Detailed breakdown of portfolio returns and allocations",
    progress: 100,
    status: "completed",
  },
  {
    id: "4",
    title: "Risk Assessment",
    description: "Current risk exposure and volatility analysis",
    progress: 0,
    status: "pending",
  },
  {
    id: "5",
    title: "Technical Indicators",
    description: "RSI, MACD, and moving average signals",
    progress: 42,
    status: "running",
  },
];

const Index = () => {
  const [reports, setReports] = useState<Report[]>(initialReports);

  // Simulate progress updates for running reports
  useEffect(() => {
    const interval = setInterval(() => {
      setReports((prevReports) =>
        prevReports.map((report) => {
          if (report.status === "running" && report.progress < 100) {
            const newProgress = Math.min(report.progress + Math.random() * 10, 100);
            const newStatus: ReportStatus = newProgress >= 100 ? "completed" : "running";
            
            if (newStatus === "completed" && report.status === "running") {
              toast.success(`${report.title} completed!`);
            }
            
            return {
              ...report,
              progress: Math.round(newProgress),
              status: newStatus,
            };
          }
          return report;
        })
      );
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleRunReport = (id: string) => {
    setReports((prevReports) =>
      prevReports.map((report) =>
        report.id === id
          ? { ...report, status: "running" as ReportStatus, progress: 0 }
          : report
      )
    );
    toast.success("Report started successfully");
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card/50 backdrop-blur-sm sticky top-0 z-10">
        <div className="container mx-auto px-4 py-6">
          <div className="flex items-center gap-3">
            <div className="h-10 w-10 rounded-lg bg-primary/20 flex items-center justify-center border border-primary/30">
              <div className="h-6 w-6 rounded bg-primary shadow-[0_0_10px_rgba(0,255,136,0.5)]" />
            </div>
            <div>
              <h1 className="text-2xl font-bold text-foreground glow-text">
                Report Dashboard
              </h1>
              <p className="text-sm text-muted-foreground">
                Monitor and execute your analysis reports
              </p>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        {/* Stats Bar */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Total Reports</p>
            <p className="text-2xl font-bold text-foreground">{reports.length}</p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Running</p>
            <p className="text-2xl font-bold text-primary glow-text">
              {reports.filter((r) => r.status === "running").length}
            </p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Completed</p>
            <p className="text-2xl font-bold text-primary">
              {reports.filter((r) => r.status === "completed").length}
            </p>
          </div>
          <div className="bg-card border border-border rounded-lg p-4">
            <p className="text-sm text-muted-foreground mb-1">Pending</p>
            <p className="text-2xl font-bold text-foreground">
              {reports.filter((r) => r.status === "pending").length}
            </p>
          </div>
        </div>

        {/* Reports Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {reports.map((report) => (
            <ReportCard key={report.id} report={report} onRun={handleRunReport} />
          ))}
        </div>
      </main>
    </div>
  );
};

export default Index;
